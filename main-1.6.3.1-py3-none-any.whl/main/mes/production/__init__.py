from flask import Blueprint
bp = Blueprint('production', __name__)

from . import monitor, bad_statistic, bad_revise, anomaly_revise, \
    material_check, issuance, inbound, get_bad_statistic, production_overall, \
    inj_param, first_part

