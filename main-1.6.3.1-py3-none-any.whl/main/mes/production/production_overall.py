import datetime

from flask import jsonify, render_template, request, session

from main.mes.production import bp
from main.model1 import *
from main.model2 import *
from main.model2 import db_session as db_model2
from main.tictoc import *
# from sqlalchemy.event import listen
# from sqlalchemy.pool import Pool
#
#
# def my_on_connect(dbapi_con):
#     print('new', dbapi_con)
#
#
# listen(db_session, 'after_commit', my_on_connect)


@bp.route('/production_overall')
def production_overall():
    return render_template('main/production/production_overall_horizontal_v2.html')


def fun_machine_list(building):
    q_machine = MachineList.query.filter(MachineList.building == building).all()
    q_machine_conn = Machine.query.all()
    machine_map = {}
    for machine in q_machine_conn:
        machine_map[machine.MachineName] = machine.MachineId
    result = {}
    for machine in q_machine:
        result[machine.machine_code] = {'building': machine.building,
                                        'machine_name': machine.machine_name,
                                        'machine_oracle_id': machine.id,
                                        'machine_conn_id': machine_map[machine.machine_name] if machine_map.get(
                                            machine.machine_name) else None}

    return result


def fun_compare_schedule_actual_chart(machine_list, now, today, amount, chart_order):
    result = [[], [], [], [], []]
    result[0].append('machine')
    result[1].append('total')
    result[2].append('target')
    result[3].append('real')
    result[4].append('difference')
    time = int((now - today).total_seconds() / 60)
    ids = []
    for a in chart_order:
        ids.append(machine_list[a]['machine_oracle_id'])

    q_schedule = ProduceSchedule.query.filter(ProduceSchedule.date == today.date(),
                                              ProduceSchedule.machine_id.in_(ids)).all()
    today_schedule = {}
    for schedule in q_schedule:
        today_schedule[schedule.machine_id] = schedule.amount
    for a in chart_order:
        result[0].append(machine_list[a]['machine_name'])

        result[1].append(today_schedule[machine_list[a]['machine_oracle_id']]
                         if machine_list[a]['machine_oracle_id'] in today_schedule.keys() else 0)
        result[2].append(int(today_schedule[machine_list[a]['machine_oracle_id']] / (24 * 60) * time)
                         if machine_list[a]['machine_oracle_id'] in today_schedule.keys() else 0)

        result[3].append(
            amount[machine_list[a]['machine_conn_id']] if amount.get(machine_list[a]['machine_conn_id']) else 0)
        result[4].append(abs(int(result[3][-1]) - int(result[2][-1])))

    return result


@bp.route('/ajax_get_machine_state')
def ajax_get_machine_state():
    t = tic()
    if 'machine_list' in session.keys():
        machine_list = session['machine_list']
    else:
        machine_list = fun_machine_list("A18")
        session['machine_list'] = machine_list
    now = datetime.datetime.now()
    if now.time() < datetime.time(7, 40, 0):
        tomorrow = datetime.datetime(now.year, now.month, now.day, 7, 40, 0)
        today = tomorrow + datetime.timedelta(days=-1)
    else:
        today = datetime.datetime(now.year, now.month, now.day, 7, 40, 0)
        tomorrow = today + datetime.timedelta(days=1)
    # todo: 加速這個查詢

    q_count = db_session.query(SpcRecord.MachineId, func.count('*').label('count')) \
        .filter(SpcRecord.TimeStemp >= str(today), SpcRecord.TimeStemp < str(tomorrow)) \
        .group_by(SpcRecord.MachineId)

    amount = {}
    # todo: 乘上模穴數
    for count in q_count:
        amount[count.MachineId] = count.count * 2

    result = []
    q_state = db_model2.query(InjParam.MachineId, InjParam.MachStateId, InjParam.CstAvgTime).all()
    state = {}
    for sta in q_state:
        state[sta[0]] = {'machine_conn_id': sta[0],
                         'machine_state': sta[1],
                         'CstAvgTime': sta[2]}
        if sta[0] in amount.keys():
            state[sta[0]]['QcTolCnt'] = amount[sta[0]]
        else:
            state[sta[0]]['QcTolCnt'] = 0

    for machine in machine_list.keys():
        temp = {}
        temp['building'] = machine_list[machine]['building']
        temp['machine_name'] = machine_list[machine]['machine_name']
        temp['machine_state'] = state[machine_list[machine]['machine_conn_id']]['machine_state'] if state.get(
            machine_list[machine]['machine_conn_id']) else 0
        temp['QcTolCnt'] = state[machine_list[machine]['machine_conn_id']]['QcTolCnt'] if state.get(
            machine_list[machine]['machine_conn_id']) else 0
        temp['CstAvgTime'] = state[machine_list[machine]['machine_conn_id']]['CstAvgTime'] if state.get(
            machine_list[machine]['machine_conn_id']) else 0
        temp['machine_id'] = machine_list[machine]['machine_oracle_id']
        result.append(temp)
    res = {'result': result, 'time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

    # 排圖表順序
    chart_order = ['A18CXJB12', 'A18CXJB13', 'A18CXJB14', 'A18CXJB15', 'A18CXJB16', 'A18CXJB17', 'A18CXJB18',
                   'A18CXJB19']  # 排圖表順序
    compare = fun_compare_schedule_actual_chart(machine_list, now, today, amount, chart_order)

    toc(t, 'compare')
    res['compare_schedule_actual'] = [compare]  # 使用array作為前端圖表v-for指令預留
    return jsonify(res)


@bp.route('/ajax_get_machine_detail', methods=['POST'])
def ajax_get_machine_detail():
    data = request.get_data()
    data = json.loads(data)
    print(data)
    q_machine = MachineList.query.filter(MachineList.building == data['building'],
                                         MachineList.machine_name == data['machine_name']).first()
    result = {}
    result['tonnage'] = q_machine.machine_tonnage
    result['brand'] = q_machine.machine_brand
    result['type'] = q_machine.machine_type
    return jsonify(result)


@bp.route('/ajax_get_machine_detail_schedule', methods=['POST'])
def ajax_get_machine_detail_schedule():
    data = request.get_data()
    data = json.loads(data)
    print(data)
    now = datetime.datetime.now()
    if now.time() < datetime.time(7, 40, 0):
        today = datetime.datetime.today() + datetime.timedelta(days=-1)
    else:
        today = datetime.datetime.today()
    today = datetime.datetime(today.year, today.month, today.day, 7, 40, 0)
    q_schedule = ProduceSchedule.query.filter(ProduceSchedule.date == today.date(),
                                              ProduceSchedule.machine_id == data['machine_id']).first()
    result = {}
    if q_schedule is None:
        return jsonify({'amount': '-', 'mold': '-', 'error': 'schedule is None.'})
    else:
        q_mold = MoldList.query.filter(MoldList.id == q_schedule.mold_id).first()
        result['amount'] = q_schedule.amount
        result['inj_product_name'] = q_schedule.product_name
        result['mold'] = q_mold.mold_number + ' ' + q_mold.mold_number_f
        result['cave'] = q_mold.cave_number
    # todo: 需優化
    machine_list = session['machine_list']
    machine_code = data['building'] + 'CXJ' + data['machine_name']
    try:
        count_tol = db_session.query(SpcRecord.MachineId) \
            .filter(SpcRecord.MachineId == machine_list[machine_code]['machine_conn_id'],
                    SpcRecord.TimeStemp >= '2019-11-01',
                    SpcRecord.TimeStemp < str(now.date())).count()
        result['mold_total'] = count_tol
    except:
        print('計算累計模次失敗')

    return jsonify(result)
