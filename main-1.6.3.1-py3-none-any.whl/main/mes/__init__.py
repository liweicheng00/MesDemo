from flask import Blueprint, render_template, jsonify, request
from flask_principal import Permission, RoleNeed

bp1 = Blueprint('auth', __name__)

"""權限管理"""
admin_permission = Permission(RoleNeed('super'))
user_permission = Permission(RoleNeed('user'))


@bp1.errorhandler(403)
def no_permission(e):
    if 'XMLHttpRequest' in request.headers.keys():
        if request.headers['X-Requested-With'] == 'XMLHttpRequest':
            return jsonify({'error': e})
        else:
            return jsonify({'error': "What happened?"})
    else:
        return render_template('no_authority.html')

from . import auth