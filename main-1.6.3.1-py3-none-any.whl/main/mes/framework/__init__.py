from flask import Blueprint
bp = Blueprint('frame', __name__)

from . import frame, upload_data