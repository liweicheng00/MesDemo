from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Table, Date, Text, Numeric, Float, DateTime,\
    func, and_, or_
from sqlalchemy.orm import scoped_session, sessionmaker, relationship, backref, load_only
from sqlalchemy.ext.declarative import declarative_base
from flask_login import UserMixin
from sqlalchemy.schema import Sequence
import os, json
import datetime

os.environ["NLS_LANG"] = "GERMAN_GERMANY.UTF8"
engine = create_engine('oracle+cx_oracle://mold_stat:Fox$20190119@10.194.176.43:1526/webdb', echo=False, encoding='utf8')
db_session = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))
Base = declarative_base()
Base.query = db_session.query_property()

association_table = Table(
    'user_role_association',
    Base.metadata,
    Column('user_id', Integer, ForeignKey('user.id')),
    Column('role_id', Integer, ForeignKey('role.id'))
)


class User(Base, UserMixin):
    __tablename__ = 'user'
    id_seq = Sequence('id_seq', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    password = Column(String(120), unique=True, nullable=False)
    name = Column(String(20), unique=False, nullable=False)
    position_id = Column(Integer, ForeignKey('user_position.id'))  # N>>1
    # position = relationship('Position', backref="user")
    role = relationship('Role', secondary=association_table)  # N>>N

    def to_dict(self):
        """將數據轉為字典"""
        dictionary = self.__dict__
        if "_sa_instance_state" in dictionary:
            del dictionary["_sa_instance_state"]
        return dictionary

    def __repr__(self):
        """讓print這個物件的時候，看起來好看"""
        return '<User %r>' % self.username


class Position(Base):
    __tablename__ = 'user_position'
    id_seq = Sequence('id_user_position', metadata=Base.metadata)
    id = Column(Integer, primary_key=True)
    position = Column(String(80), unique=True, nullable=False)
    user = relationship('User', backref="user_position")
    def __repr__(self):
        """讓print這個物件的時候，看起來好看"""
        return '<position %r>' % self.position


class Role(Base):
    __tablename__ = 'role'
    id = Column(Integer, primary_key=True)
    role = Column(String(80), unique=True, nullable=False)
    user = relationship('User', secondary=association_table, back_populates='role')

    def to_dict(self):
        """將數據轉為字典"""
        dictionary = self.__dict__
        if "_sa_instance_state" in dictionary:
            del dictionary["_sa_instance_state"]
        return dictionary

    def __init__(self, id=None, role=None):
        self.id = id
        self.role = role

    def __repr__(self):
        """讓print這個物件的時候，看起來好看"""
        return '<Role %r>' % self.role


class ProductList(Base):
    __tablename__ = 'product_list'
    id_seq = Sequence('id_product_list', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    honhai_pn = Column(String(80), unique=True, nullable=False)
    product_code = Column(String(80), unique=False, nullable=False)
    product_name = Column(String(80), unique=True, nullable=False)
    ps = Column(Text, unique=False, nullable=True)


class MaterialList(Base):
    __tablename__ = 'material_list'
    id_seq = Sequence('id_material_list', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    material_part_number = Column(String(80), unique=True, nullable=False)
    material_type = Column(String(80), unique=False, nullable=True)
    material_spec = Column(String(80), unique=False, nullable=True)
    color_number = Column(String(80), unique=False, nullable=True)
    color = Column(String(80), unique=False, nullable=True)
    material_vendor = Column(String(80), unique=False, nullable=True)
    alm_state = Column(Integer, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class MachineList(Base):
    __tablename__ = 'machine_list'
    id_seq = Sequence('id_machine_list', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    building = Column(String(80), unique=False, nullable=True)
    machine_name = Column(String(80), unique=True, nullable=False)
    machine_code = Column(String(80), unique=True, nullable=False)
    machine = Column(String(80), unique=False, nullable=True)
    machine_type = Column(String(80), unique=False, nullable=True)
    machine_tonnage = Column(String(80), unique=False, nullable=True)
    machine_brand = Column(String(80), unique=False, nullable=True)
    machine_no = Column(String(80), unique=False, nullable=True)
    machine_location = Column(String(80), unique=False, nullable=True)
    machine_state = Column(Integer, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class MoldList(Base):
    __tablename__ = 'mold_list'
    id_seq = Sequence('id_mold_list', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    mold_number = Column(String(80), unique=True, nullable=False)
    mold_number_f = Column(String(80), unique=True, nullable=False)
    cave_number = Column(Integer, unique=False, nullable=False)
    ejection_mode = Column(String(80), unique=False, nullable=True)
    mold_state = Column(Integer, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class PNList(Base):
    __tablename__ = 'pn_list'
    id_seq = Sequence('id_pn_list', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    part_number = Column(String(80), unique=True, nullable=False)
    inj_product_name = Column(String(80), unique=False, nullable=False)
    product_name_en = Column(String(80), unique=False, nullable=False)
    std_produce = Column(Float, unique=False, nullable=False)
    std_cycle_time = Column(Float, unique=False, nullable=False)
    ps = Column(Text, unique=False, nullable=True)
    piece = Column(Integer, unique=False, nullable=True)


class Bom(Base):
    __tablename__ = 'bom'
    id_seq = Sequence('id_bom_list', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    product_id = Column(Integer, ForeignKey('product_list.id'))
    product_list = relationship('ProductList', backref="bom")
    pnlist_id = Column(Integer, ForeignKey('pn_list.id'))
    pn_list = relationship('PNList', backref="bom")
    ps = Column(Text, unique=False, nullable=True)
    available = Column(String(80), unique=False, nullable=True)


class PNMaterialList(Base):
    __tablename__ = 'pn_material_list'
    id_seq = Sequence('id_pn_material_list', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    pnlist_id = Column(Integer, ForeignKey('pn_list.id'))
    pn_list = relationship('PNList', backref="pn_material_list")
    material_id = Column(Integer, ForeignKey('material_list.id'))
    material_list = relationship('MaterialList', backref="pn_material_list")
    material_weight = Column(Numeric, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class ProduceSchedule(Base):
    __tablename__ = 'produce_schedule'
    id_seq = Sequence('id_produce_schedule', metadata=Base.metadata)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(Date, unique=False, nullable=False)
    machine_id = Column(Integer, ForeignKey('machine_list.id'))
    machine_list = relationship('MachineList', backref="produce_schedule")
    mold_id = Column(Integer, ForeignKey('mold_list.id'))
    mold_list = relationship('MoldList', backref="produce_schedule")
    pnlist_id = Column(Integer, ForeignKey('pn_list.id'))
    pn_list = relationship('PNList', backref="produce_schedule")
    amount = Column(Float, unique=False, nullable=False)
    product_name = Column(String(80), unique=False, nullable=True)
    produce_order = Column(String(80), unique=False, nullable=True)
    version = Column(String(80), unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class MoldPnAssociation(Base):
    __tablename__ = 'mold_pn_association'
    id_seq = Sequence('id_mold_pn_association', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    mold_id = Column(Integer, ForeignKey('mold_list.id'))
    pnlist_id = Column(Integer, ForeignKey('pn_list.id'))
    mold_list = relationship('MoldList', backref="mold_pn_association")
    pn_list = relationship('PNList', backref="mold_pn_association")
    ps = Column(Text, unique=False, nullable=True)


class DailyReport(Base):
    __tablename__ = 'daily_report'
    id_seq = Sequence('id_daily_report', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(Date, unique=False, nullable=False)
    building = Column(String(20), unique=False, nullable=False)
    machine = Column(String(20), unique=False, nullable=False)
    part_number = Column(String(20), unique=False, nullable=False)
    mold = Column(String(20), unique=False, nullable=True)
    produce_amount = Column(Integer, unique=False, nullable=True)
    bad_amount = Column(Integer, unique=False, nullable=True)
    bad_percent = Column(Float, unique=False, nullable=True)
    bad_ppm = Column(Integer, unique=False, nullable=True)
    lost_time = Column(Float, unique=False, nullable=True)
    real_cycle_time = Column(Float, unique=False, nullable=True)
    record_state = Column(Integer, unique=False, nullable=False)
    additional_amount = Column(Integer, unique=False, nullable=True)


class DailyClassReport(Base):
    __tablename__ = 'daily_class_report'
    id_seq = Sequence('id_daily_class_report', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    daily_report_id = Column(Integer, ForeignKey('daily_report.id'))
    daily_report = relationship('DailyReport', backref="daily_class_report")
    work_class = Column(String(5), unique=False, nullable=False)
    bad_amount = Column(Integer, unique=False, nullable=True)
    box_number = Column(Integer, unique=False, nullable=True)
    box_name = Column(String(20), unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class BadList(Base):
    __tablename__ = 'bad_list'
    id_seq = Sequence('id_bad_list', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    bad_name = Column(String(20), unique=True, nullable=False)
    bad_code = Column(String(20), unique=True, nullable=False)
    ps = Column(Text, unique=False, nullable=True)


class AnomalyList(Base):
    __tablename__ = 'anomaly_list'
    id_seq = Sequence('id_anomaly_list', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    anomaly_type_id = Column(Integer, ForeignKey('anomaly_type_list.id'))
    anomaly_type_list = relationship('AnomalyTypeList', backref="anomaly_list")
    anomaly_name = Column(String(20), unique=False, nullable=False)
    anomaly_code = Column(String(20), unique=True, nullable=False)
    ps = Column(Text, unique=False, nullable=True)


class AnomalyTypeList(Base):
    __tablename__ = 'anomaly_type_list'
    id_seq = Sequence('id_anomaly_type_list', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    anomaly_type = Column(String(20), unique=False, nullable=False)
    anomaly_type_code = Column(String(20), unique=True, nullable=False)
    ps = Column(Text, unique=False, nullable=True)


class BadRecord(Base):
    __tablename__ = 'bad_record'
    id_seq = Sequence('id_bad_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    daily_report_id = Column(Integer, ForeignKey('daily_report.id'))
    daily_report = relationship('DailyReport', backref="bad_record")
    daily_class_report_id = Column(Integer, ForeignKey('daily_class_report.id'))
    daily_class_report = relationship('DailyClassReport', backref="bad_record")
    bad_id = Column(Integer, ForeignKey('bad_list.id'))
    bad_list = relationship('BadList', backref="bad_record")
    record_time = Column(DateTime, unique=False, nullable=False)
    cause = Column(Text, unique=False, nullable=True)
    improve = Column(Text, unique=False, nullable=True)
    responsible = Column(String(20), unique=False, nullable=True)
    finish_date = Column(DateTime, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class AnomalyRecord(Base):
    __tablename__ = 'anomaly_record'
    id_seq = Sequence('id_anomaly_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    daily_report_id = Column(Integer, ForeignKey('daily_report.id'))
    daily_report = relationship('DailyReport', backref="anomaly_record")
    anomaly_id = Column(Integer, ForeignKey('anomaly_list.id'))
    anomaly_list = relationship('AnomalyList', backref="anomaly_record")
    begin_time = Column(DateTime, unique=False, nullable=False)
    end_time = Column(DateTime, unique=False, nullable=False)
    lost_time = Column(Float, unique=False, nullable=False)
    improve = Column(Text, unique=False, nullable=True)
    responsible = Column(String(20), unique=False, nullable=True)
    finish_date = Column(Date, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class MaterialDispatch(Base):
    __tablename__ = 'material_dispatch'
    id_seq = Sequence('id_material_dispatch', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(Date, unique=False, nullable=False)
    building = Column(String(20), unique=False, nullable=True)
    pnlist_id = Column(Integer, ForeignKey('pn_list.id'))
    pn_list = relationship('PNList', backref="material_dispatch")
    material_id = Column(Integer, ForeignKey('material_list.id'))
    material_list = relationship('MaterialList', backref="material_dispatch")
    demand_weight = Column(Float, unique=False, nullable=True)
    remain_weight = Column(Float, unique=False, nullable=True)
    dispatch_weight = Column(Float, unique=False, nullable=True)
    get_weight = Column(Float, unique=False, nullable=True)
    state = Column(Integer, unique=False, nullable=True)

    def to_dict(self):
        """將數據轉為字典"""
        dictionary = self.__dict__
        if "_sa_instance_state" in dictionary:
            del dictionary["_sa_instance_state"]
        return dictionary


class MaterialCheck(Base):
    __tablename__ = 'material_check'
    id_seq = Sequence('id_material_check', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(Date, unique=False, nullable=False)
    building = Column(String(20), unique=False, nullable=False)
    material_id = Column(Integer, ForeignKey('material_list.id'))
    material_list = relationship('MaterialList', backref="material_check")
    get_amount = Column(Integer, unique=False, nullable=False)
    feeding_bucket = Column(Integer, unique=False, nullable=False)
    dry_bucket = Column(Integer, unique=False, nullable=False)
    material_bucket = Column(Integer, unique=False, nullable=False)
    total = Column(Integer, unique=False, nullable=False)


class IssuanceRecord(Base):
    __tablename__ = 'issuance_record'
    id_seq = Sequence('id_issuance_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(DateTime, unique=False, nullable=False)
    pnlist_id = Column(Integer, ForeignKey('pn_list.id'))
    pn_list = relationship('PNList', backref="issuance_record")
    remain = Column(Integer, unique=False, nullable=False)
    box_amount = Column(Integer, unique=False, nullable=True)
    pallet = Column(Integer, unique=False, nullable=True)
    total_amount = Column(Integer, unique=False, nullable=False)
    responsible = Column(String(20), unique=False, nullable=True)


class InboundRecord(Base):
    __tablename__ = 'inbound_record'
    id_seq = Sequence('id_inbound_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(DateTime, unique=False, nullable=False)
    pnlist_id = Column(Integer, ForeignKey('pn_list.id'))
    pn_list = relationship('PNList', backref="inbound_record")
    remain = Column(Integer, unique=False, nullable=False)
    box_amount = Column(Integer, unique=False, nullable=True)
    pallet = Column(Integer, unique=False, nullable=True)
    total_amount = Column(Integer, unique=False, nullable=False)
    responsible = Column(String(20), unique=False, nullable=True)


class SignTableList(Base):
    __tablename__ = 'sign_table_list'
    id_seq = Sequence('id_sign_table_list', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    table_name = Column(String(80), unique=True, nullable=False)
    db_table_name = Column(String(80), unique=True, nullable=False)
    name = Column(String(80), unique=True, nullable=True)


class SignProcessList(Base):
    __tablename__ = 'sign_process_list'
    id_seq = Sequence('id_sign_process_list', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    table_list_id = Column(Integer, ForeignKey('sign_table_list.id'))
    sign_table_list = relationship('SignTableList', backref="sign_process_list")
    process_name = Column(String(20), unique=False, nullable=True)


class SignProcessListDetail(Base):
    __tablename__ = 'sign_process_list_detail'
    id_seq = Sequence('id_sign_process_list_detail', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    process_list_id = Column(Integer, ForeignKey('sign_process_list.id'))
    sign_process_list = relationship('SignProcessList', backref="sign_process_list_detail")
    user_id = Column(Integer, ForeignKey('user.id'))
    user = relationship('User', backref="sign_process_list_detail")
    signer = Column(String(20), unique=False, nullable=False)
    sign_order = Column(Integer, unique=False, nullable=False)


class SignEvent(Base):
    __tablename__ = 'sign_event'
    id_seq = Sequence('id_sign_event', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(DateTime, unique=False, nullable=False)
    table_list_id = Column(Integer, ForeignKey('sign_table_list.id'))
    sign_table_list = relationship('SignTableList', backref="sign_event")
    process_name_id = Column(Integer, ForeignKey('sign_process_list.id'))
    sign_process_list = relationship('SignProcessList', backref="sign_event")
    sign_state = Column(Integer, unique=False, nullable=False)
    form_index = Column(String(20), unique=False, nullable=True)
    initiator = Column(String(20), unique=False, nullable=True)
    initiator_id = Column(Integer, unique=False, nullable=True)


class SignerState(Base):
    __tablename__ = 'signer_state'
    id_seq = Sequence('id_signer_state', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    event_id = Column(Integer, ForeignKey('sign_event.id'))
    sign_event = relationship('SignEvent', backref="signer_state")
    process_list_detail_id = Column(Integer, ForeignKey('sign_process_list_detail.id'))
    process_list_detail = relationship('SignProcessListDetail', backref="signer_state")
    signer = Column(String(20), unique=False, nullable=False)
    signer_order = Column(Integer, unique=False, nullable=False)
    signer_state = Column(Integer, unique=False, nullable=False)
    sign_date = Column(DateTime, unique=False, nullable=False)
    flag = Column(Numeric, unique=False, nullable=False)
    ps = Column(Text, unique=False, nullable=True)


class InjParamRecord(Base):
    __tablename__ = 'inj_param_record'
    id_seq = Sequence('id_inj_param_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    TIMESTAMP = Column(DateTime, primary_key=False)
    MACHINE_ID = Column(Numeric, primary_key=False)
    MOLD_ID = Column(Numeric, primary_key=False)
    part_number = Column(String(80), unique=False, nullable=True)
    NowTn2 = Column(Numeric, primary_key=False)
    NowT1 = Column(Numeric, primary_key=False)
    NowT2 = Column(Numeric, primary_key=False)
    NowT3 = Column(Numeric, primary_key=False)
    NowT4 = Column(Numeric, primary_key=False)
    ChrSpd3 = Column(Numeric, primary_key=False)
    ChrPrs3 = Column(Numeric, primary_key=False)
    ChrPos4 = Column(Numeric, primary_key=False)
    ChrPos4_ChrPos3 = Column(Numeric, primary_key=False)
    InjPos0 = Column(Numeric, primary_key=False)
    InjPos1 = Column(Numeric, primary_key=False)
    InjPos2 = Column(Numeric, primary_key=False)
    InjPos3 = Column(Numeric, primary_key=False)
    InjPos4 = Column(Numeric, primary_key=False)
    InjSpd0 = Column(Numeric, primary_key=False)
    InjSpd1 = Column(Numeric, primary_key=False)
    InjSpd2 = Column(Numeric, primary_key=False)
    InjSpd3 = Column(Numeric, primary_key=False)
    InjSpd4 = Column(Numeric, primary_key=False)
    InjPrs0 = Column(Numeric, primary_key=False)
    InjPrs1 = Column(Numeric, primary_key=False)
    InjPrs2 = Column(Numeric, primary_key=False)
    InjPrs3 = Column(Numeric, primary_key=False)
    InjPrs4 = Column(Numeric, primary_key=False)
    TtimeInjP = Column(Numeric, primary_key=False)
    HldPrs0 = Column(Numeric, primary_key=False)
    HldPrs1 = Column(Numeric, primary_key=False)
    HldPrs2 = Column(Numeric, primary_key=False)
    HldPrs3 = Column(Numeric, primary_key=False)
    HldTime0 = Column(Numeric, primary_key=False)
    HldTime1 = Column(Numeric, primary_key=False)
    HldTime2 = Column(Numeric, primary_key=False)
    HldTime3 = Column(Numeric, primary_key=False)
    TimeDchr = Column(Numeric, primary_key=False)
    BfCstTime = Column(Numeric, primary_key=False)
    DryTemp = Column(Numeric, primary_key=False)
    DryTime = Column(Numeric, primary_key=False)
    DewPoint = Column(Numeric, primary_key=False)
    OilTemp = Column(Numeric, primary_key=False)
    MoTnMale = Column(Numeric, primary_key=False)
    MoTnFemale = Column(Numeric, primary_key=False)
    MoSlider = Column(Numeric, primary_key=False)
    Plate = Column(Numeric, primary_key=False)
    HtRunT1 = Column(Numeric, primary_key=False)
    HtRunT2 = Column(Numeric, primary_key=False)
    HtRunT3 = Column(Numeric, primary_key=False)
    HtRunT4 = Column(Numeric, primary_key=False)
    HtRunT5 = Column(Numeric, primary_key=False)
    HtRunT6 = Column(Numeric, primary_key=False)
    HtRunT7 = Column(Numeric, primary_key=False)
    HtRunT8 = Column(Numeric, primary_key=False)
    HtRunT9 = Column(Numeric, primary_key=False)
    HtRunT10 = Column(Numeric, primary_key=False)
    HtRunT11 = Column(Numeric, primary_key=False)
    HtRunT12 = Column(Numeric, primary_key=False)
    HtRunT13 = Column(Numeric, primary_key=False)
    HtRunT14 = Column(Numeric, primary_key=False)
    HtRunT15 = Column(Numeric, primary_key=False)

    def to_dict(self):
        """將數據轉為字典"""
        dictionary = self.__dict__
        if "_sa_instance_state" in dictionary:
            del dictionary["_sa_instance_state"]
        return dictionary


class InjParamStandard(Base):
    __tablename__ = 'inj_param_standard'
    id_seq = Sequence('id_inj_param_standard', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    TIMESTAMP = Column(DateTime, primary_key=False)
    MACHINE_ID = Column(Numeric, primary_key=False)
    MOLD_ID = Column(Numeric, primary_key=False)
    part_number = Column(String(80), unique=False, nullable=True)
    flag = Column(Integer, primary_key=False)
    Tn2 = Column(Numeric, primary_key=False)
    T1 = Column(Numeric, primary_key=False)
    T2 = Column(Numeric, primary_key=False)
    T3 = Column(Numeric, primary_key=False)
    T4 = Column(Numeric, primary_key=False)
    ChrSpd3 = Column(Numeric, primary_key=False)
    ChrPrs3 = Column(Numeric, primary_key=False)
    ChrPos4 = Column(Numeric, primary_key=False)
    ChrPos4_ChrPos3 = Column(Numeric, primary_key=False)
    InjPos0 = Column(Numeric, primary_key=False)
    InjPos1 = Column(Numeric, primary_key=False)
    InjPos2 = Column(Numeric, primary_key=False)
    InjPos3 = Column(Numeric, primary_key=False)
    InjPos4 = Column(Numeric, primary_key=False)
    InjSpd0 = Column(Numeric, primary_key=False)
    InjSpd1 = Column(Numeric, primary_key=False)
    InjSpd2 = Column(Numeric, primary_key=False)
    InjSpd3 = Column(Numeric, primary_key=False)
    InjSpd4 = Column(Numeric, primary_key=False)
    InjPrs0 = Column(Numeric, primary_key=False)
    InjPrs1 = Column(Numeric, primary_key=False)
    InjPrs2 = Column(Numeric, primary_key=False)
    InjPrs3 = Column(Numeric, primary_key=False)
    InjPrs4 = Column(Numeric, primary_key=False)
    TtimeInjP = Column(Numeric, primary_key=False)
    HldPrs0 = Column(Numeric, primary_key=False)
    HldPrs1 = Column(Numeric, primary_key=False)
    HldPrs2 = Column(Numeric, primary_key=False)
    HldPrs3 = Column(Numeric, primary_key=False)
    HldTime0 = Column(Numeric, primary_key=False)
    HldTime1 = Column(Numeric, primary_key=False)
    HldTime2 = Column(Numeric, primary_key=False)
    HldTime3 = Column(Numeric, primary_key=False)
    TimeDchr = Column(Numeric, primary_key=False)
    EjtPos3 = Column(Numeric, primary_key=False)
    EjtSpd3 = Column(Numeric, primary_key=False)
    EjtPrs3 = Column(Numeric, primary_key=False)
    EjtPos0 = Column(Numeric, primary_key=False)
    EjtSpd0 = Column(Numeric, primary_key=False)
    EjtPrs0 = Column(Numeric, primary_key=False)
    MopPos3 = Column(Numeric, primary_key=False)
    MopPrs3 = Column(Numeric, primary_key=False)
    MclPos5 = Column(Numeric, primary_key=False)
    MclPos4 = Column(Numeric, primary_key=False)
    MclPrs4 = Column(Numeric, primary_key=False)
    TimeLpr = Column(Numeric, primary_key=False)
    TimeDch = Column(Numeric, primary_key=False)

    BfInjTime = Column(Numeric, primary_key=False)
    BfCstTime = Column(Numeric, primary_key=False)

    DryTemp = Column(Numeric, primary_key=False)
    DryTime = Column(Numeric, primary_key=False)
    DewPoint = Column(Numeric, primary_key=False)
    OilTemp = Column(Numeric, primary_key=False)
    MoTnMale = Column(Numeric, primary_key=False)
    MoTnFemale = Column(Numeric, primary_key=False)
    MoSlider = Column(Numeric, primary_key=False)
    Plate = Column(Numeric, primary_key=False)
    HtRunT1 = Column(Numeric, primary_key=False)
    HtRunT2 = Column(Numeric, primary_key=False)
    HtRunT3 = Column(Numeric, primary_key=False)
    HtRunT4 = Column(Numeric, primary_key=False)
    HtRunT5 = Column(Numeric, primary_key=False)
    HtRunT6 = Column(Numeric, primary_key=False)
    HtRunT7 = Column(Numeric, primary_key=False)
    HtRunT8 = Column(Numeric, primary_key=False)
    HtRunT9 = Column(Numeric, primary_key=False)
    HtRunT10 = Column(Numeric, primary_key=False)
    HtRunT11 = Column(Numeric, primary_key=False)
    HtRunT12 = Column(Numeric, primary_key=False)
    HtRunT13 = Column(Numeric, primary_key=False)
    HtRunT14 = Column(Numeric, primary_key=False)
    HtRunT15 = Column(Numeric, primary_key=False)
    ClmFrc = Column(Numeric, primary_key=False)
    ProdWeight = Column(Numeric, primary_key=False)
    FeederWeight = Column(Numeric, primary_key=False)
    CnsmptPH = Column(Numeric, primary_key=False)


    def to_dict(self):
        """將數據轉為字典"""
        dictionary = self.__dict__
        if "_sa_instance_state" in dictionary:
            del dictionary["_sa_instance_state"]
        return dictionary


class BadCause(Base):
    __tablename__ = 'bad_cause'
    id_seq = Sequence('id_bad_cause', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    week = Column(Integer, unique=False, nullable=False)
    inj_part_number = Column(String(80), unique=False, nullable=False)
    bad_name = Column(String(80), unique=False, nullable=False)
    ppm = Column(Integer, unique=False, nullable=False)
    pics = Column(Integer, unique=False, nullable=False)
    cause = Column(Text, unique=False, nullable=False)
    improvement = Column(Text, unique=False, nullable=False)
    finish_date = Column(String(80), unique=False, nullable=False)
    response = Column(String(80), unique=False, nullable=False)


class BfInjEndMonitor(Base):
    __tablename__ = 'injection_end_monitor'
    machineid = Column(Integer, unique=False, nullable=False, primary_key=True)
    start_time = Column(DateTime, unique=False, nullable=False)
    end_time = Column(DateTime, unique=False, nullable=False)
    error = Column(Float, unique=False, nullable=False, primary_key=True)
    trend = Column(Float, unique=False, nullable=False)


class BackendDemand(Base):
    __tablename__ = 'backend_demand'
    id_seq = Sequence('id_backend_demand', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    date = Column(Date, unique=False, nullable=False)
    product_name = Column(String(80), unique=False, nullable=False)
    part_number = Column(String(80), unique=False, nullable=False)
    demand_amount = Column(Integer, unique=False, nullable=False)
    open_num = Column(Integer, unique=False, nullable=False)
    revise_amount = Column(Integer, unique=False, nullable=False)
    revise_open_num = Column(Integer, unique=False, nullable=False)
    scheduled_num = Column(Integer, unique=False, nullable=True)
    state = Column(Integer, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)


class FirstPartRecord(Base):
    __tablename__ = 'first_part_record'
    id_seq = Sequence('id_first_part_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    send_time = Column(DateTime, unique=False, nullable=False)
    finish_time = Column(DateTime, unique=False, nullable=True)
    pnlist_id = Column(Integer, unique=False, nullable=False)
    part_number = Column(String(80), unique=False, nullable=False)
    machine_id = Column(Integer, unique=False, nullable=False)
    machine_name = Column(String(80), unique=False, nullable=False)
    mold_id = Column(Integer, unique=False, nullable=False)
    mold_number = Column(String(80), unique=False, nullable=False)
    mold_number_f = Column(String(80), unique=False, nullable=False)
    material_id = Column(Integer, unique=False, nullable=True)
    material_part_number = Column(String(80), unique=False, nullable=True)
    grn_no = Column(String(80), unique=False, nullable=True)
    batch_number = Column(String(80), unique=False, nullable=True)
    examine_dependence = Column(String(80), unique=False, nullable=True)
    type = Column(String(80), unique=False, nullable=True)
    type_id = Column(Integer, unique=False, nullable=True)
    all_determination = Column(String(80), unique=False, nullable=True)
    dimension_id = Column(Integer, unique=False, nullable=True)
    ps = Column(Text, unique=False, nullable=True)
    building = Column(String(80), unique=False, nullable=True)
    dimension_state = Column(Integer, unique=False, nullable=True)
    examine_state = Column(Integer, unique=False, nullable=True)

    def to_dict(self):
        """將數據轉為字典"""
        dictionary = self.__dict__
        if "_sa_instance_state" in dictionary:
            del dictionary["_sa_instance_state"]
        if "send_time" in dictionary:
            try:
                dictionary["send_time"] = dictionary["send_time"].strftime('%Y-%m-%d %H:%M:%S')
            except:
                pass
            else:
                pass
        if "finish_time" in dictionary:
            try:
                dictionary["finish_time"] = dictionary["finish_time"].strftime('%Y-%m-%d %H:%M:%S')
            except:
                pass
            else:
                pass
        return dictionary


class Dimension(Base):
    __tablename__ = 'dimension'
    id_seq = Sequence('id_dimension', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    mold_id = Column(Integer, unique=False, nullable=True)
    pnlist_id = Column(Integer, unique=False, nullable=False)
    dim = Column(Integer, unique=False, nullable=False)
    dim_name = Column(String(80), unique=False, nullable=True)
    measure_tool = Column(String(80), unique=False, nullable=True)
    upper_limit = Column(Float, unique=False, nullable=True)
    lower_limit = Column(Float, unique=False, nullable=True)


class DimensionRecord(Base):
    __tablename__ = 'dimension_record'
    id_seq = Sequence('id_dimension_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    cave_number = Column(Integer, unique=False, nullable=False)
    first_part_id = Column(Integer, unique=False, nullable=False)
    dimension_id = Column(Integer, unique=False, nullable=False)
    measure_data = Column(Float, unique=False, nullable=True)
    determination = Column(String(80), unique=False, nullable=True)
    ng = Column(Integer, unique=False, nullable=False)


class ExamineRecord(Base):
    __tablename__ = 'examine_record'
    id_seq = Sequence('id_examine_record', metadata=Base.metadata, cache=2)
    id = Column(Integer, id_seq, primary_key=True)
    cave_number = Column(Integer, unique=False, nullable=False)
    first_part_id = Column(Integer, unique=False, nullable=False)
    examine_1 = Column(Integer, unique=False, nullable=True)
    examine_2 = Column(Integer, unique=False, nullable=True)
    examine_3 = Column(Integer, unique=False, nullable=True)
    examine_4 = Column(Integer, unique=False, nullable=True)
    examine_5 = Column(Integer, unique=False, nullable=True)
    examine_6 = Column(Integer, unique=False, nullable=True)
    examine_7 = Column(Integer, unique=False, nullable=True)
    examine_8 = Column(Integer, unique=False, nullable=True)
    examine_9 = Column(Integer, unique=False, nullable=True)
    examine_10 = Column(Integer, unique=False, nullable=True)
    examine_11 = Column(Integer, unique=False, nullable=True)
    examine_12 = Column(Integer, unique=False, nullable=True)
    examine_13 = Column(Integer, unique=False, nullable=True)
    examine_14 = Column(Integer, unique=False, nullable=True)
    examine_15 = Column(Integer, unique=False, nullable=True)
    examine_16 = Column(Integer, unique=False, nullable=True)
    examine_17 = Column(Integer, unique=False, nullable=True)
    examine_18 = Column(Integer, unique=False, nullable=True)
    examine_19 = Column(Integer, unique=False, nullable=True)
    determination = Column(String(80), unique=False, nullable=True)

    def to_dict(self):
        """將數據轉為字典"""
        dictionary = self.__dict__
        if "_sa_instance_state" in dictionary:
            del dictionary["_sa_instance_state"]
        return dictionary


def init_db():
    """建立表"""
    Base.metadata.create_all(bind=engine)


def print_test_user(username=None):
    if username is not None:
        for a in db_session.query(User).filter_by(username=username):
            print('A:', a.username, 'has relationship with')
            for b in a.role:
                print('\tRole:', b.role_name)
    else:
        for a in db_session.query(User):
            print('A:', a.username, 'has relationship with')
            for b in a.role:
                print('\tRole:', b.role_name)


if __name__ == '__main__':

    # init_db()
    q = FirstPartRecord.query.all()
    # q_sub0 = db_session.query(MachineList.id).filter(MachineList.building == "A18").subquery()
    # q_sub = db_session \
    #     .query(ProduceSchedule.pnlist_id,
    #            func.sum(ProduceSchedule.amount)) \
    #     .filter(ProduceSchedule.date == datetime.datetime.strptime('2020-01-07', '%Y-%m-%d'),
    #             ProduceSchedule.machine_id.in_(q_sub0)) \
    #     .group_by(ProduceSchedule.pnlist_id) \
    #     .order_by(ProduceSchedule.pnlist_id) \
    #     .subquery('t2')
    # q_schedule = db_session.query(q_sub,
    #                               PNList.part_number,
    #                               PNList.inj_product_name,
    #                               PNMaterialList.material_id,
    #                               PNMaterialList.material_weight,
    #                               MaterialList.material_part_number,
    #                               MaterialList.color,
    #                               MaterialList.material_spec,
    #                               MaterialList.color_number) \
    #     .join(PNList, PNList.id == q_sub.c.pnlist_id) \
    #     .outerjoin(PNMaterialList, PNMaterialList.pnlist_id == PNList.id) \
    #     .join(MaterialList, MaterialList.id == PNMaterialList.material_id)
    # for a in q_schedule:
    #     print(a)

    # q = InjParamStandard.query.all()
    # for qq in q:
    #     qq.part_number = '009-0041-7742'
    #     print(qq.part_number)
    #     db_session.add(qq)
    # db_session.commit()
    # q = db_session.query(InjParamStandard.MOLD_ID).distinct()
    # for qq in q:
    #     print(qq)
    #
    # mold_map = {'49': 59, '50': 60, '51': 61, '52': 62, '53': 63, '54': 64, '55': 65, '56': 66, '57': 67, '58': 68}
    # for i in range(49, 59):
    #     q = InjParamRecord.query.filter(InjParamRecord.MOLD_ID == i).all()
    #     for qq in q:
    #
    #         qq.MOLD_ID = mold_map[str(i)]
    #         print(qq.id, i, qq.MOLD_ID)
    #         db_session.add(qq)
    # db_session.commit()
    # q = ProduceSchedule.query.filter(ProduceSchedule.pnlist_id == 41).all()

    # q = BBB.query.order_by(BBB.id).all()
    # for qq in q:
    #     print(qq.id, ' ', qq.mold_id)
    #     qqq = ProduceSchedule.query.filter(ProduceSchedule.id == qq.id).first()
    #     qqq.mold_id = qq.mold_id
    #     print(qqq.id, ' ', qqq.mold_id)
    #     db_session.add(qqq)
    # db_session.commit()


    # subq_t2 = db_session.query(func.max(DailyReport.date).label('maxdate'), DailyReport.building,
    #                            DailyReport.machine, DailyReport.mold) \
    #     .group_by(DailyReport.building, DailyReport.machine, DailyReport.mold) \
    #     .filter(DailyReport.part_number == '009-0041-7742', DailyReport.machine == 'B12') \
    #     .order_by(func.max(DailyReport.date).desc()) \
    #     .subquery('t2')
    # q_daily = db_session.query(subq_t2, MachineList.id, DailyReport.bad_ppm, DailyReport.produce_amount) \
    #     .join(DailyReport, and_(DailyReport.date == subq_t2.c.maxdate,
    #                             DailyReport.building == subq_t2.c.building,
    #                             DailyReport.machine == subq_t2.c.machine,
    #                             DailyReport.mold == subq_t2.c.mold)) \
    #     .join(MachineList, and_(MachineList.building == subq_t2.c.building,
    #                             MachineList.machine_name == subq_t2.c.machine)) \
    #     .order_by(subq_t2.c.maxdate.desc()) \
    #     .all()
    #
    #
    # for q in q_daily:
    #     print(q)
    # new_standard = InjParamStandard()
    # db_session.add(new_standard)
    # db_session.commit()
    # q = SignTableList.query.all()
    # for a in q:
    #     print(a)
    # with open("static/json/InjParam_all.json", 'r', encoding='utf8') as rf:
    #     load_dict = json.load(rf)
    #
    # for key in load_dict.keys():
    #     print(key)
    #     db_session.execute('Alter table inj_param_record add (' + key + ' NUMBER)')


    # a = ['AC1', 'AC2', 'AC3', 'AC4', 'AC5']
    # b = ['成型類', '模具類', '設備類', '自動化類', '系統類']
    # new_anomaly = []
    # for aa in range(0, len(a)):
    #     print(aa)
    #     db_session.add(AnomalyTypeList(anomaly_type_code=a[aa], anomaly_type=b[aa]))
    # db_session.commit()



    # q_user = User.query.filter_by(username = 'admin').first()
    # q_role = Role.query.filter_by(role='super').first()
    # print(q_user)
    # print(q_role)
    # q_user.role = [q_role]
    # db_session.add(q_user)
    # db_session.commit()



    # try:
    #     new_user = User.query.filter_by(username='test4').first()
    #     db_session.delete(new_user)
    #     db_session.commit()
    # except:
    #     pass
    # finally:
    #     pass
    # try:
    #     new_user = Position.query.filter_by(id=1).first()
    #     db_session.delete(new_user)
    #     db_session.commit()
    # except:
    #     pass
    # finally:
    #     pass
    # try:
    #     new_user = Role.query.filter(Role.id >= 3).all()
    #     # print(new_user)
    #     for new in new_user:
    #         db_session.delete(new)
    #         db_session.commit()
    # except:
    #     pass
    # finally:
    #     pass
    #
    # new_user = User(username='test4', password='test4', name="鄭力維")
    # role1 = Role(id=3, role='test')
    # role2 = Role(id=4, role='test2')
    # position = Position(id=1, position='工程師')
    # new_user.role = [role1, role2]
    # new_user.position = position
    # db_session.add(new_user)
    # db_session.commit()
    # db_session.add(position)
    # db_session.commit()
    #
    # users = User.query.filter_by(username='test4').first()
    # users.role  # 沒這行找不到role
    # users.position
    # print(users.position)
    # user = users.to_dict()
    # print(user)
    # positions = Position.query.all()
    # print(positions)
    # for pos in positions:
    #     print(pos)
    #     # pos.user  # 沒這行找不到role
    #     print(pos.user)



